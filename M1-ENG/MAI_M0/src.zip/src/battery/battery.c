/*
 * battery.c
 *
 * Created: 2014/3/12 20:18:22
 *  Author: john
 */ 

#include "battery.h"
#include "ad/ad.h"
#include "conf_adc.h"
#include "device/device.h"
#include "conf_battery.h"
#include <avr/eeprom.h>

void battery_init(void)
{
	ioport_set_pin_dir(BATTERY_PIN_CHARGE, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(BATTERY_PIN_ADC, IOPORT_DIR_INPUT);
}

void battery_store_last_level(bool pre)
{
	static bool done = false;
	if (battery_is_charging())
	{
		return;
	}
	if (pre)
	{
		done = false;
		return;
	}
	if (done)
	{
		return;
	}
	eeprom_busy_wait();
	eeprom_write_word(BATTERY_EEPROM_LAST_LEVEL_ADDRESS,battery_get_level());
	eeprom_busy_wait();
	eeprom_write_word(BATTERY_EEPROM_LAST_TIME_ADDRESS,rtc_get_time());
	done = true;
}

static inline uint16_t battery_get_level_charging(void)
{
	uint16_t time, level;
	eeprom_busy_wait();
	level = eeprom_read_word(BATTERY_EEPROM_LAST_LEVEL_ADDRESS);
	eeprom_busy_wait();
	time = rtc_get_time() - eeprom_read_word(BATTERY_EEPROM_LAST_TIME_ADDRESS);
 	return min(8, level + (time>>11));
} 
static inline uint16_t battery_get_level_uncharging(void)
{
	static uint16_t last_ad_resault = 2000;
	const static uint16_t level_map[] = {1326,1361,1378,1389,1406,1423,1447,1460};
	uint16_t i;
	uint16_t current_resault;
	static uint8_t last_level = 8;
	
	ad_swap_channel(ADCCH_BATTERY);
	current_resault = ad_read();
	adc_disable(&ADCA);
	
// 	if (!device_is_high(DEVICE_FAN_ENABLE))
// 	{
// 		current_resault -= (current_resault>>8)*5;
// 	}
	//ad_swap_channel(ADCCH_BATTERY);
	last_ad_resault = (current_resault + ((uint32_t)last_ad_resault)*31)>>5;
	for (i=0;i<sizeof(level_map)/sizeof(uint16_t);i++)
	{
		if (last_ad_resault < level_map[i])
		{
			break;
		}
	}
	if((i&1) == 0)
	{
		last_level = i;
	}
	else if (abs((int8_t)i-(int8_t)last_level)>1)
	{
		last_level = (i>>1)<<1;
	}
	return last_level;
}

uint16_t battery_get_level(void)
{
	if (battery_is_charging())
	{
		return battery_get_level_charging();
	}
	else
	{
		return battery_get_level_uncharging();
	}
}