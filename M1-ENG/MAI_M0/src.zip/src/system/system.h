/*
 * system.h
 *
 * Created: 2014/3/14 16:13:59
 *  Author: Airj
 */ 


#ifndef SYSTEM_H_
#define SYSTEM_H_


typedef enum
{
	SYSTEM_POWERDOFF = 0,
	SYSTEM_REALTIME,
	SYSTEM_POWERSAVE,
	SYSTEM_HISTORY,
} system_status_t;

#define KEY_CLICK_TIME 5
#define KEY_HOLD_TIME 50
#define KEY_LONG_HOLD_TIME 100
#define KEY_IGNORE_HOLD_TIME 200

#define CIRCLE_POWERSAVE_CALCULATE_MASK 0xffffL

#define CIRCLE_OLED_UPDATE_MASK 0x3f
#define CIRCLE_AUTO_POWER_OFF_INDEX (30000UL)
#define CIRCLE_DUST_CALCULATE_INDEX (7500UL)

#endif /* SYSTEM_H_ */