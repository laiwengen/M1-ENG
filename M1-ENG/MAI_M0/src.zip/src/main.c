/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
#include <asf.h>
//#include "debug/debug.h"
#include "conf_sys.h"
#include "device/device.h"
#include "system/system.h"
#include "oled/oled.h"
#include "history/history.h"

#include "ad/ad.h"
#include "algorithm/algorithm.h"
#include "battery/battery.h"

#define MULTIPLY 0.77*0.67
#define TABLE_LENGTH 24
#define MUTIP_130 140


typedef struct 
{
	uint8_t downlast;
	uint8_t uplast;
	bool level;
} key_t;

key_t * g_power_key_pointer = NULL;


////////////////////////////////////////////////////

static uint32_t data2pm25(uint32_t data)
{
	//return data;
// 	
	uint8_t i=0;
	uint32_t pm25;
	uint32_t base;
// // 	const static uint16_t multi[TABLE_LENGTH+1] = {87, 95, 100, 107, 117, 128, 128, 134, 167, 190, 212, 233, 292, 326, 386, 407, 480, 486, 486, 486, 500, 600, 680, 750, 750};
// // 	const static uint32_t line[TABLE_LENGTH+1] = {75000, 63000, 58000, 51800, 45000, 39800, 38800, 35200, 26200, 21800, 19000, 16700, 12300, 10000, 7500, 6300, 4500, 3600, 3000, 2300,1900, 1100, 959, 400, 0};
	const static uint16_t dx[] = {400,500,200,800,400,  700,600,900,1800,1200,	2500,2300,4400,2300,2800,	4400,9000,3600,1000,5200,	6800,6200,5000,1200};
	const static uint16_t dy[] = {3000,2800,800,2900,1678,  3402,2916,4104,4041,3309,	3650,3316,2995,1369,1140,	2334,3414,2496,1280,1706,	2776,2574,1850,5400};
	data = data>>2;
// 	return data;
	base = 0;
	for(i=0;i<(sizeof(dx)/sizeof(uint16_t))-1;i++)
	{
		if (data<dx[i])
		{
			break;
		}
		data -= dx[i];
		base += dy[i];
	}
	pm25 = base+ (data*dy[i])/dx[i];
// 	
	
	
// 	
// 	
// 	
// 	
// 	
// 	for(i=0;i<TABLE_LENGTH;i++)
// 	{
// 		if(data>line[i])
// 		{
// 			break;
// 		}
// 	}
// 	
// 	//pm25 = data*multi[i]/100;
// 	if(i==0)
// 	{
// 		pm25 = data*87/MUTIP_130;
// 	}
// 	if(i==TABLE_LENGTH)
// 	{
// 		pm25 = data*500/MUTIP_130;
// 	}
// 	else
// 	{
// 		pm25 = ( data*(multi[i-1]+(multi[i]-multi[i-1])*(line[i-1] - data)/(line[i-1]-line[i])) )/MUTIP_130;
// 	}
//  	uint8_t i=0;
//  	int32_t pm25;
//  	const static uint32_t d2p[20][2] = {{86000,134600},{83800, 121300},{79500, 105400},{75700,90400},{66500,59500},{55000,46300},{51100,38400},{43771,27600},{41000,23900},{37500,18600},{33600,15200},{30200,12000},{24400,9400},{18800,8343},{11100,6900},{5200,5200},{2450,3300},{1800,400},{0,0}};
//  
//  	uint8_t d2plen = 20;
//  
//  	for (i=0; i<d2plen; i++)
//  	{
//  		if ((data)>d2p[i][1])
//  		{
//  			break;
//  		}
//  	}
//  	if (i==0)
//  	{
//  		pm25 = d2p[0][0]+((d2p[0][0]-d2p[1][0])*(int32_t)((int32_t)(data)-d2p[0][1]))/(d2p[0][1]-d2p[1][1]);
//  	}
//  	else if (i==d2plen)
//  	{
//  		pm25 = d2p[d2plen-1][0]+(d2p[d2plen-2][0]-(d2p[d2plen-1][0])*(int32_t)(d2p[d2plen-1][1]-(int32_t)(data)))/(d2p[d2plen-1][1]-d2p[d2plen-2][1]);
//  	}
//  	else
//  	{
//  		pm25 = d2p[i][0]+((d2p[i-1][0]-d2p[i][0])*(int32_t)((int32_t)(data)-d2p[i][1]))/(d2p[i-1][1]-d2p[i][1]);
//  	}
//  	if (pm25<0)
//  	{
//  		pm25 = 0;
//  	}
// 	//pm25 = data>>4;
//pm25+=pm25>>1;
	pm25 -= pm25>>2;
	if (pm25>99999UL)
	{
		pm25 = 99999UL;
	}
	return (uint32_t)pm25;
}

//////////////////////////////////////////////////

static inline void circle_tc_init(void)
{
	tc_enable(&CIRCLE_TC);
	tc_set_wgm(&CIRCLE_TC,TC_WG_NORMAL);
	tc_write_period(&CIRCLE_TC, 2000);
	tc_write_clock_source(&CIRCLE_TC, TC_CLKSEL_DIV256_gc);
}

static inline bool is_time_for_new_circle(void)
{
	return tc_is_overflow(&CIRCLE_TC);
}

static void rtc_callback( uint32_t count)
{
	history_store_rtc(count);
	rtc_set_alarm_relative(10);
	battery_store_last_level(true);
}

static inline void scan_key(system_status_t * current_system_status, bool * system_status_changed, bool * sub_function)
{
	enum key_index_t {POWER = 0, SELECT = 1, MODE = 2};
	static system_status_t last_system_status = SYSTEM_REALTIME;
	
	static key_t key[3];
	const static port_pin_t key_pin[] = {DEVICE_KEY_POWER,DEVICE_KEY_SELECT,DEVICE_KEY_MODE};
	uint8_t i;
	
	g_power_key_pointer = &key[0];
	
	for (i=0; i< sizeof(key)/sizeof(key_t);i++)
	{
		if (device_is_high(key_pin[i]))
		{
			if (key[i].level == false && key[i].downlast >= KEY_CLICK_TIME)
			{
				key[i].level = true;
				key[i].uplast = 0;
			}
			key[i].uplast = min( (key[i].uplast)+1, 0xF0);
		} 
		else
		{
			if (key[i].level == true && key[i].uplast >= KEY_CLICK_TIME)
			{
				key[i].level = false;
				key[i].downlast = 0;
			}
			key[i].downlast = min( (key[i].downlast)+1, 0xF0);
		}
	}
	if (*current_system_status == SYSTEM_POWERDOFF)
	{
		if (key[POWER].downlast == KEY_LONG_HOLD_TIME && key[POWER].level == false)
		{
			*current_system_status = last_system_status;
			*system_status_changed = true;
		}
	}
	else
	{	
		if ((key[POWER].downlast == KEY_LONG_HOLD_TIME && key[POWER].level == false)\
			|| (key[POWER].downlast > KEY_CLICK_TIME && key[POWER].downlast < KEY_LONG_HOLD_TIME && key[POWER].level == true && key[POWER].uplast == KEY_CLICK_TIME)\
			|| (key[POWER].downlast > KEY_IGNORE_HOLD_TIME && key[POWER].level == false))
		{
			last_system_status = *current_system_status;
			*current_system_status = SYSTEM_POWERDOFF;
			*system_status_changed = true;
		}
	}
	if (*current_system_status != SYSTEM_POWERDOFF)
	{
		if ((key[MODE].downlast == KEY_HOLD_TIME && key[MODE].level == false)\
		|| (key[MODE].downlast > KEY_CLICK_TIME && key[MODE].downlast < KEY_HOLD_TIME && key[MODE].level == true && key[MODE].uplast == KEY_CLICK_TIME))
		{
			if (*current_system_status != SYSTEM_HISTORY)
			{
				(*current_system_status) ++;
			}
			else
			{
				(*current_system_status) = SYSTEM_REALTIME;
			}
			*system_status_changed = true;
		}
	}
	if (*current_system_status != SYSTEM_POWERDOFF)
	{
		if ((key[SELECT].downlast == KEY_HOLD_TIME && key[SELECT].level == false)\
		|| (key[SELECT].downlast > KEY_CLICK_TIME && key[SELECT].downlast < KEY_HOLD_TIME && key[SELECT].level == true && key[SELECT].uplast == KEY_CLICK_TIME))
		{
			*sub_function = true;
		}
		else if ((key[SELECT].downlast >= KEY_HOLD_TIME && key[SELECT].level == false) && (*current_system_status == SYSTEM_HISTORY || *current_system_status == SYSTEM_HISTORY))
		{
			*sub_function = true;
		}
	}
}

static void circle_callback(void)
{
	static uint32_t circle_index=0;
	static system_status_t current_system_status = SYSTEM_POWERDOFF;
	static uint8_t oled_updata_index;
	static uint32_t power_save_calculate_index;
	static uint32_t last_operate_index;
	static bool is_hold = false;
	static uint8_t pre_power_off_left = 0;
	
	static bool need_recalculate = false;
	//static uint32_t pm25_times_100 = 0;
	//static uint32_t pm10 = 0;
	//static uint8_t sleep_delay = 0;
	static Dust_Info_t dust_info[2] = {{.xmin = 0,.xmax = 30},{.xmin = 20, .xmax = 50}};
	
	static oled_status_t oled_status;
	static history_t history;
	uint8_t battery_level;
	bool is_charging;
	
	bool last_hold = false;
	bool sub_function = false;
	bool system_status_changed = false;
	bool has_operation = false;
	bool need_calculate = false;
	
	circle_index ++;
	
	scan_key(&current_system_status,&system_status_changed, &sub_function);
	has_operation = system_status_changed || sub_function;
	
	is_charging = battery_is_charging();
	
	if (!(current_system_status == SYSTEM_POWERDOFF && !is_charging))
	{
		device_enable(DEVICE_VCC_12V_POWER_ENABLE);
		oled_enable();
	}
	if (system_status_changed)
	{
		is_hold = false;
	}
	if (has_operation)
	{
		power_save_calculate_index = ((circle_index - 1) & CIRCLE_POWERSAVE_CALCULATE_MASK);
		oled_updata_index = circle_index & CIRCLE_OLED_UPDATE_MASK;
		last_operate_index = circle_index;
	}
	
	if (current_system_status != SYSTEM_POWERSAVE)
	{
		if (circle_index - last_operate_index > CIRCLE_AUTO_POWER_OFF_INDEX && current_system_status != SYSTEM_POWERDOFF)
		{
 			current_system_status = SYSTEM_POWERDOFF; //auto turn off, 2min no operation
 			oled_updata_index = circle_index & CIRCLE_OLED_UPDATE_MASK;
		}
	}
	else
	{
		if ((circle_index & CIRCLE_POWERSAVE_CALCULATE_MASK)==power_save_calculate_index)
		{
			last_operate_index = circle_index;  //power save auto start
			is_hold = false;
		}
	}
	battery_level = battery_get_level();
	battery_store_last_level(false);
	
	if (battery_level == 0 && !is_charging)
	{
		if (pre_power_off_left == 0 &&(/*!device_is_high(DEVICE_KEY_POWER)||*/current_system_status != SYSTEM_POWERDOFF))
		{
			pre_power_off_left = 50*3;
			oled_updata_index = circle_index & CIRCLE_OLED_UPDATE_MASK;
		}
		current_system_status = SYSTEM_POWERDOFF; //auto turn off for low battary
	}
	else if (is_charging)
	{
		pre_power_off_left = 0;
	}
	last_hold = is_hold;
	if (sub_function)
	{
		is_hold = !is_hold;
	}
	if (circle_index - last_operate_index > CIRCLE_DUST_CALCULATE_INDEX)
	{
		is_hold = true; // auto hold
	}
	
	if (current_system_status == SYSTEM_HISTORY)
	{
		bool no_data_left = false;
		if (has_operation)
		{
			no_data_left = !history_read_next(&history, system_status_changed);
			oled_status.pm2_5 = history.data;
		}
		oled_status.time = rtc_get_time() - history.time;
		if (no_data_left)
		{
			current_system_status = SYSTEM_REALTIME;
			is_hold = false;
		}
	}
	if (current_system_status == SYSTEM_REALTIME || current_system_status == SYSTEM_POWERSAVE)
	{
		need_calculate = true;
		if (need_recalculate)
		{
			need_recalculate = false;
			algorithm_calculate(dust_info,2,true);
		}
		
		if (is_hold && !last_hold && sub_function)
		{
			history_t his_tmp = {.time = rtc_get_time(), .data = data2pm25(dust_info[0].dust_value)};
			history_write(&his_tmp);
		}
	}
	
	if (pre_power_off_left != 0)
	{
		pre_power_off_left --;
		if (pre_power_off_left == 0)
		{
			oled_updata_index = circle_index & CIRCLE_OLED_UPDATE_MASK;
		}
	}
	
	if (((circle_index & CIRCLE_OLED_UPDATE_MASK)==oled_updata_index))
	{
		oled_status.is_charge = is_charging;
		if (pre_power_off_left!=0)
		{
			oled_status.show_low_power = true;
			battery_level = 0;
		}
		else
		{
			oled_status.show_low_power = false;
			
		}
		if (current_system_status == SYSTEM_HISTORY)
		{
			oled_status.pm2_5 = history.data;
		}
		else
		{
			//oled_status.pm2_5 = dust_info[0].dust_value;
			//oled_status.pm2_5 = min(99999UL,dust_info[0].tmp_value);
			oled_status.pm2_5 = data2pm25(dust_info[0].dust_value);
			oled_status.pm10 = data2pm25(dust_info[0].dust_value + (dust_info[0].dust_value >>2)+ dust_info[1].dust_value);
		}
				
				
		oled_status.aqi_level = get_aqi_level(oled_status.pm2_5);
		oled_status.battery_level = battery_level;
		oled_status.is_hold = is_hold;
		oled_status.system_status = current_system_status;
		//oled_status.pm2_5_times_100 = rtc_get_time();
		oled_update(&oled_status);
		
	}
	else if (((circle_index+1) & CIRCLE_OLED_UPDATE_MASK) == oled_updata_index)
	{
		
		if (current_system_status != SYSTEM_POWERDOFF )
		{
			device_disable(DEVICE_LASER_ENABLE);
			algorithm_calibrate();
		}
	}
	else 
	{
		if(!is_hold && need_calculate)
		{
			device_enable(DEVICE_AVCC_3V_POWER_ENABLE);
			device_enable(DEVICE_FAN_ENABLE);
			device_enable(DEVICE_LASER_ENABLE);
			
 			algorithm_calculate(dust_info,2,need_recalculate);
			//device_disable(DEVICE_LASER_ENABLE);
		}
	}
	if (!(!is_hold && need_calculate))
	{
		device_disable(DEVICE_FAN_ENABLE);
		device_disable(DEVICE_LASER_ENABLE);
		device_disable(DEVICE_AVCC_3V_POWER_ENABLE);
	}
	
	if (current_system_status == SYSTEM_POWERDOFF)
	{
		need_recalculate = true;
	}
	if (current_system_status == SYSTEM_POWERDOFF && !is_charging && pre_power_off_left==0)
	{
		device_disable(DEVICE_VCC_12V_POWER_ENABLE);
		oled_disable();
		if (device_is_high(DEVICE_KEY_POWER))
		{
			PORTE.INTFLAGS &= PIN0_bm;
			pmic_enable_level(PMIC_LVL_HIGH);
			sleep_enable();
			sleep_enter();
	
			pmic_disable_level(PMIC_LVL_HIGH);
		}
	}
}

ISR(PORTE_INT0_vect)
{
	sleep_disable();
	g_power_key_pointer->downlast = 0;
	g_power_key_pointer->uplast = KEY_CLICK_TIME;
// 	device_enable(DEVICE_AVCC_3V_POWER_ENABLE);
// 	delay_ms(10);
// 	algorithm_init();
// 	device_disable(DEVICE_AVCC_3V_POWER_ENABLE);
}

ISR(PORTD_INT0_vect)
{
	sleep_disable();
}

#if 0
#include "util/delay.h"

static inline uint16_t battery_get_level_uncharging(void)
{
	static uint16_t last_ad_resault = 2000;
	const static uint16_t level_map[] = {1326,1361,1378,1389,1406,1423,1457,1472};
	uint16_t i;
	uint16_t current_resault;
	
	ad_swap_channel(ADCCH_BATTERY);
	current_resault = ad_read();
	adc_disable(&ADCA);
	
	//if (!device_is_high(DEVICE_FAN_ENABLE))
	//{
		//current_resault -= (current_resault>>8)*5;
	//}
	////ad_swap_channel(ADCCH_BATTERY);
	//last_ad_resault = (current_resault + ((uint32_t)last_ad_resault)*31)>>5;
	//for (i=0;i<sizeof(level_map)/sizeof(uint16_t);i++)
	//{
		//if (last_ad_resault < level_map[i])
		//{
			//break;
		//}
	//}
	return current_resault;
}

void main(void )
{
	sysclk_init();
	rtc_init();
	rtc_set_time(history_resume_rtc());
	rtc_set_callback(rtc_callback);
	rtc_set_alarm_relative(10);
	pmic_enable_level(CONFIG_RTC_OVERFLOW_INT_LEVEL);
	circle_tc_init();
	device_init();
	ad_init();
	oled_init();
	
	
	device_enable(DEVICE_AVCC_3V_POWER_ENABLE);
	device_enable(DEVICE_ANALOG_ENABLE);
	device_enable(DEVICE_FAN_ENABLE);
	device_enable(DEVICE_LASER_ENABLE);
	device_enable(DEVICE_VCC_12V_POWER_ENABLE);
	
	oled_enable();
	_delay_ms(2000);
	oled_status_t ost;
	ost.system_status = SYSTEM_REALTIME;
	ost.aqi_level = 0;
	ost.battery_level = 4;
	ost.is_charge = false;
	ost.is_hold = false;
	ost.pm10 =0;
	ost.show_low_power = false;
	ost.time = 1000;
	while(1)
	{
		ost.pm2_5 = battery_get_level_uncharging();
		oled_update(&ost);
		_delay_ms(1000);
	}
}
#endif

#if 1
int main (void)
{
	sysclk_init();
	rtc_init();
	rtc_set_time(history_resume_rtc());
	rtc_set_callback(rtc_callback);
	rtc_set_alarm_relative(10);
	pmic_enable_level(CONFIG_RTC_OVERFLOW_INT_LEVEL);
	circle_tc_init();
	device_init();
	ad_init();
	oled_init();
	Enable_global_interrupt();
	{
		PORTD.INT0MASK = PIN0_bm;
		PORTD.INTCTRL = 0x03;
		PORTE.INT0MASK = PIN2_bm;
		PORTE.INTCTRL = 0x03;
		PORTE.PIN2CTRL = 0X02;
	}
	sleep_set_mode(SLEEP_SMODE_PSAVE_gc);
	
	
// 	device_enable(DEVICE_AVCC_3V_POWER_ENABLE);
// 	delay_ms(10);
// 	algorithm_init();
// 	device_disable(DEVICE_AVCC_3V_POWER_ENABLE);
	algorithm_init();

	while(true)
	{
		if (!is_time_for_new_circle())
		{
			continue;
		}
		tc_clear_overflow(&CIRCLE_TC);
		circle_callback();
	}
	// Insert application code here, after the board has been initialized.
}
#endif