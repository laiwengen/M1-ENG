/*
 * conf_sys.h
 *
 * Created: 2014/3/14 19:23:14
 *  Author: Airj
 */ 


#ifndef CONF_SYS_H_
#define CONF_SYS_H_

#define CIRCLE_TC TCD0



#endif /* CONF_TC_H_ */