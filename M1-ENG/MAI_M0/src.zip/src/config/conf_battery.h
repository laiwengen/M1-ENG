/*
 * conf_battery.h
 *
 * Created: 2014/3/19 15:57:14
 *  Author: Airj
 */ 


#ifndef CONF_BATTERY_H_
#define CONF_BATTERY_H_



#define BATTERY_EEPROM_LAST_LEVEL_ADDRESS 0x208U
#define BATTERY_EEPROM_LAST_TIME_ADDRESS 0x20AU

#endif /* CONF_BATTERY_H_ */