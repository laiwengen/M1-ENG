/*
 * ad.c
 *
 * Created: 2014/3/20 9:57:58
 *  Author: Airj
 */ 

#include "ad/ad.h"

void ad_swap_channel( enum adcch_positive_input channel)
{
	struct adc_channel_config adcch_conf;
	if (adc_is_enabled(&ADCA))
	{
		adc_disable(&ADCA);
		delay_us(10);
	}
	adcch_read_configuration(&ADCA, ADC_CH0, &adcch_conf);
	adcch_set_input(&adcch_conf, channel, ADCCH_NEG_NONE, 1);
	adcch_write_configuration(&ADCA, ADC_CH0, &adcch_conf);
	delay_us(10);
}

uint16_t ad_read(void)
{
	uint16_t rst;
	
	if (!adc_is_enabled(&ADCA))
	{
		adc_enable(&ADCA);
		delay_us(10);
	}
	adc_start_conversion(&ADCA, ADC_CH0);
	adc_wait_for_interrupt_flag(&ADCA, ADC_CH0);
	rst = adc_get_result(&ADCA, ADC_CH0);
	return  rst;
}
